<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Oracle" tilewidth="8" tileheight="8" tilecount="16384" columns="128">
 <image source="16x16 assembled.png" width="1024" height="1024"/>
</tileset>
