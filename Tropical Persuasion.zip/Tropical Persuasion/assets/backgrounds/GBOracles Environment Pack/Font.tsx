<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Font" tilewidth="8" tileheight="8" tilecount="224" columns="16">
 <image source="../../../../../../GameBoyStudio/ProjectFolder/Example/assets/fonts/gbs-mono.png" width="128" height="112"/>
</tileset>
